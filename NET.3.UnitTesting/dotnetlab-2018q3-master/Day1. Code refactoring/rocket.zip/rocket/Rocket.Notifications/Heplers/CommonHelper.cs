﻿namespace Rocket.Notifications.Heplers
{
    /// <summary>
    /// Общий хелпер.
    /// </summary>
    internal static class CommonHelper
    {
        public const string ContainerKey = "container";
    }
}
