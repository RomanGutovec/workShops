﻿using Rocket.BL.Common.Models.ReleaseList;

namespace Rocket.BL.Common.Models.Pagination
{
    public class TvSeriesPageInfo : PageInfo<TVSeries>
    {
    }
}
