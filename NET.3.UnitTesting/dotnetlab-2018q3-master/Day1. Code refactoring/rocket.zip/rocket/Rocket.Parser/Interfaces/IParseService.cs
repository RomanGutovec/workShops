﻿namespace Rocket.Parser.Interfaces
{
    internal interface IParseService
    {
        /// <summary>
        /// Выполнение парсинга.
        /// </summary>
        void Parse();
    }
}
