﻿namespace Rocket.BL.Common.DtoModels.ReleaseList
{
    public class TvSeriesDetailsDto
    {
        public int TvSeriesId { get; set; }

        public string TvSeriesTitleRu { get; set; }

        public string TvSeriesTitleEn { get; set; }
    }
}
