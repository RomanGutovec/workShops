﻿namespace Rocket.Parser.Helpers
{
    /// <summary>
    /// Lostfilm-хэлпер для доплнительных ссылок.
    /// </summary>
    internal static class LostfilmAddUrlForBase
    {
        public const string AdditionalUrlToSerialList = "/series";
    }
}
