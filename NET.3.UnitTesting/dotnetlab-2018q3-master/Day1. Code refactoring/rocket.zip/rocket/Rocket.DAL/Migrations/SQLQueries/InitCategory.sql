﻿  INSERT INTO dbo.Category(Code, Name)
	VALUES 
		(1, 'Сериал'),
		(2, 'Фильм'),
		(3, 'Музыкальный трэк');


