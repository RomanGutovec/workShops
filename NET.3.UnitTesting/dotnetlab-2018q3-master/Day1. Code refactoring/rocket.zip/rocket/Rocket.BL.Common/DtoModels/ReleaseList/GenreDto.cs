﻿namespace Rocket.BL.Common.DtoModels.ReleaseList
{
    public class GenreDto
    {
        public int Id { get; set; }

        public string Name { get; set; }
    }
}