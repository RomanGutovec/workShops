﻿INSERT INTO dbo.PersonType (Code, Name)
	VALUES 
		(1, 'Актер'),
		(2, 'Режиссер'),
		(3, 'Продюсер'),
		(4, 'Сценарист'),
		(5, 'Музыкант');


