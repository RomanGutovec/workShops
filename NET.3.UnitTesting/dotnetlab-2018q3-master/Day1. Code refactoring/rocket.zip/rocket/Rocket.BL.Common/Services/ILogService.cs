﻿namespace Rocket.BL.Common.Services
{
    public interface ILogService
    {
        string GetLogInfo();
    }
}
