﻿INSERT INTO [dbo].[Resource]
           ([Name]
           ,[ResourceLink]
		   ,[ParseIsSwitchOn]
		   ,[ParsePeriodInMinutes]
		   )
     VALUES
           ('Lostfilm'
           ,'http://www.lostfilm.tv'
		   ,1	
		   ,120
		   );


