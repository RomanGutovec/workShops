﻿using Rocket.BL.Common.Models.ReleaseList;

namespace Rocket.BL.Common.Models.Pagination
{
    public class MusicPageInfo : PageInfo<Music>
    {
    }
}
