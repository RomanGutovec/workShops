﻿namespace Rocket.Parser.Interfaces
{
    internal interface ILostfilmParser : IParser
    {
    }
}