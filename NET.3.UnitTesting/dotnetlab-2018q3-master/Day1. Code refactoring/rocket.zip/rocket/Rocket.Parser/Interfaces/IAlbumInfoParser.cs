﻿namespace Rocket.Parser.Interfaces
{
    /// <summary>
    /// Парсер для сайта album-info.ru
    /// </summary>
    internal interface IAlbumInfoParser : IParser
    {
    }
}