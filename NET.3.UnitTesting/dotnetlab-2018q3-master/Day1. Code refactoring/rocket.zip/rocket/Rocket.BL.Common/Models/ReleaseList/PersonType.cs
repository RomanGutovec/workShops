﻿namespace Rocket.BL.Common.Models.ReleaseList
{
    public class PersonType
    {
        public int Code { get; set; }

        public string Name { get; set; }
    }
}
